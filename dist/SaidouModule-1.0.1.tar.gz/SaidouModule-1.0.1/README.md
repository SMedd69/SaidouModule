Module SaidouModule possède des packages dédier à l'intelligence artificielle. Le but de ceci étant purement éducatif.

Se module contient les packages suivants :
    - SaidouPixels : Qui possède des fonctions permettant d'initialiser une image avec des pixels. La taille et les couches peuvent être choisis. Et d'autres méthodes permettant d'afficher une image, d'enregistrer l'image générer en fichier, charger les images dans une matrice Numpy.

    - SaidouNeurone : Qui possède des fonctions permettant de réaliser un réseau de neurone à plusieurs couches.

Le module est en cours de développement et libre d'accès.. 
