print("Module SaidouPixels à été importé avec succès !")
